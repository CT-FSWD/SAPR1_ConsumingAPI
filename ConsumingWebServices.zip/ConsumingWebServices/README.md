# ConsumingWebServices
Example of .NET MVC application using AJAX to create a web service
